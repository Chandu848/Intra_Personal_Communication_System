<?php
$host="localhost";
$user="root";
$pass="";
$db="tsp";
$con=mysqli_connect($host,$user,$pass,$db);
if($con)
{
	echo "Success";
}
// sql = selec* from user;


else
{
	echo "Failed to connect";
}

?>