<!DOCTYPE html>
<html>
<head>
<title>LOGIN FORM</title>
<link rel="stylesheet" type="text/css" href="logins.css">
</head>
<body>
    <dev class="login-form">
       
        <form action="login.php" method="post">
            <p>Email</p>
            <input type="text" name="email" placeholder="Email-Id">
            <p>Password</p>
            <input type="password" name="pass" placeholder="password" style="margin-bottom: 20px;">
             <input style="cursor: pointer;" type="submit" class="regbuttons" name="submit">
            <a href="Register1.php" class="ca">Create account</a>
             
        </form>
</body>
</html>