<!DOCTYPE html>
<html>
<head>
<title>REGISTRATION</title>
<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
    
    <dev class="login-form">
        
        <form action="signup.php" method="post">
            <h1>Registration</h1>
            
            <p>User Name</p>
            <input type="text" name="user" placeholder="User-Name">
            <p>Email</p>
            <input type="text" name="email" placeholder="Email" style="margin-bottom: 20px;">
            <p>Password</p>
            <input type="text" name="pass" placeholder="Pass" style="margin-bottom: 20px;">
            <p>confirm Password</p>
            <input type="text" name="cpass" placeholder="Confirm-password" style="margin-bottom: 20px;">
             <input style="cursor: pointer;" type="submit" class="regbuttons" name="submit">
             </form>
            <a href="logins.php" class="ca" style="color:black">   Already have account</a>
</body> 
</html>
