<?php
include("config.php");

$user=$_POST["user"];
$email=$_POST["email"];
$pass=$_POST["pass"];
$pass1=$_POST["cpass"];
if($pass==$pass1)
{
	$query="INSERT INTO user VALUES('$user','$email','$pass')";
	$result=mysqli_query($con,$query);
	header("Location:logins.php");
}
else 
{   
	echo '<script>alert("Password not matched")</script>';
	header("Location:register1.php");
}
?>