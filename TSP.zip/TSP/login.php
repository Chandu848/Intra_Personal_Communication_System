<?php
include ("config.php");
$email=$_POST['email'];
$pass=$_POST['pass'];
$query="SELECT * FROM user where email='$email'";
$result=mysqli_query($con,$query);

while($temp= $result->fetch_assoc())
{
	$dbpass=$temp["pass"];
	
}


if($pass==$dbpass)
{
	
			header("Location:profile.html");

	
}

else
{  
	echo '<script>alert("Password not matched")</script>';
	header("Location:logins.php");
	exit();
	
}
?>